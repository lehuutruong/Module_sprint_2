package vn.sprint_2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import vn.sprint_2.model.product.Category;
import java.util.List;

@CrossOrigin("*")
@RequestMapping("/api/home")
@RestController
public class HomeRestController {

//    @GetMapping()
//    public ResponseEntity<?> list(){
//        return
//    }

}
