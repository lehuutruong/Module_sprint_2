package vn.sprint_2.service.product;

import vn.sprint_2.model.product.Product;

import java.util.List;

public interface IProductService {
    List<Product> listProduct();
}
