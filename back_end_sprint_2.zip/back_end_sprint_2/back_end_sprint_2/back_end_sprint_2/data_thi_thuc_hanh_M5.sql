INSERT INTO `thi_thuc_hanh_m5`.`quan_ly_ve` (`id`, `diem_den`, `diem_di`, `gia`, `gio_khoi_hanh`, `ngay_khoi_hanh`, `so_luong`, `id_nha_xe`) VALUES ('1', 'a', '1', '11111', '01:01', '2022-12-12', '10', '1');
INSERT INTO `thi_thuc_hanh_m5`.`quan_ly_ve` (`id`, `diem_den`, `diem_di`, `gia`, `gio_khoi_hanh`, `ngay_khoi_hanh`, `so_luong`, `id_nha_xe`) VALUES ('2', 'b', '2', '22222', '02:02', '2022-12-12', '20', '2');
INSERT INTO `thi_thuc_hanh_m5`.`quan_ly_ve` (`id`, `diem_den`, `diem_di`, `gia`, `gio_khoi_hanh`, `ngay_khoi_hanh`, `so_luong`, `id_nha_xe`) VALUES ('3', 'c', '3', '33333', '03:03', '2022-12-12', '30', '3');
INSERT INTO `thi_thuc_hanh_m5`.`quan_ly_ve` (`id`, `diem_den`, `diem_di`, `gia`, `gio_khoi_hanh`, `ngay_khoi_hanh`, `so_luong`, `id_nha_xe`) VALUES ('4', 'd', '4', '44444', '04:04', '2022-12-12', '40', '4');
INSERT INTO `thi_thuc_hanh_m5`.`quan_ly_ve` (`id`, `diem_den`, `diem_di`, `gia`, `gio_khoi_hanh`, `ngay_khoi_hanh`, `so_luong`, `id_nha_xe`) VALUES ('5', 'e', '5', '55555', '05:05', '2022-12-12', '50', '5');
SELECT * FROM thi_thuc_hanh_m5.quan_ly_ve WHERE is_delete = 1;
